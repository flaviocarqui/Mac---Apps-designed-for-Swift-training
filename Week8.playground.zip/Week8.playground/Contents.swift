//: Playground - noun: a place where people can play

import UIKit

var str = "layground " + "Testes"


var A = 100
var B = 200

var sum = A+B
print(sum)


var message = "This tetes..."
var message2 = "Hello 222222 part"

var M = message + message2
print(M)



var str1 = "Hello"
var str2 = "Hellooouuoo"
if str1 == str2 {
    print ("Both are equal")}
    else{
    print ("Different")
}

let apples = 3
let oranges = 5
let appleSummary = "I have \(apples) apples."
let fruitSummary = "I have \(apples + oranges) pieces of fruit."

var shoppingList = ["casish", "water", "tulips", "blue    paint"]
    shoppingList[1] = "botle of water"
var occupations = [
    "Malcolm": "Captain",
    "Kaylee": "Mechanic"]
occupations["Jayne"] = "Public Relations"

print(occupations)


var Array1 = ["Alex", "Ion", "Ionic", "Positoin 3"]
print(Array1)
print (Array1[3])


let individualScores = [75, 43, 103, 87, 12]
var teamScore = 0
for score in individualScores {
    if score > 50 {
        teamScore += 3
    } else {
        teamScore += 1
    }
}
print(teamScore)


let vegetable = "red pepper"
switch vegetable {case "celery":    let vegetableComment = "Add some raisins and make ants on a log."
case "cucumber", "watercress":    let vegetableComment = "That would make a good tea sandwich."
case let x where x.hasSuffix("pepper"):     let vegetableComment = "Is it a spicy \(x)?"
default:    let vegetableComment = "Everything tastes good in soup."
}



let interestngNumbers = [
    "Prime": [2, 3, 5, 7, 11, 13],
    "Fibonacci": [1, 1, 2, 3, 5, 8],
    "Square": [1, 4, 9, 16, 25],
]
var largest = 0
for (kind, numbers) in interestngNumbers {
    for number in numbers {
        if number > largest {
            largest = number
        }
    }
}
print(largest)


var n = 100
while n < 100 {
    n = n * 2
}
print(n)


var m = 100
repeat {
    m = m * 2
} while m < 100
print(m)

var firstForLoop = 0
for i in 0..<4 {
    firstForLoop += i
}
print(firstForLoop)


func greet(name: String, day: String) -> String {
    return "Hello \(name), today is \(day)."
}
greet(name: "Bob", day: "Tuesday")





class ClimateControl {
    var temperature: Double
    var humidity: Double?
    init(temp: Double) {
        temperature = temp
    }
    init(temp: Double, hum: Double) {
        temperature = temp
        humidity = hum
    }
}


var myArray=[1,2,3,5]
var total = 0
for element in myArray {
    print("\(element) ")
    total += element
}
print(" = \(total)")


var a:Double = 100
var b = 3.14
print(a * b)




