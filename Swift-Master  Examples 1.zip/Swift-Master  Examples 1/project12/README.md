# README

Lots of people email me, tweet me, or file issues on GitHub saying that this directory contains project 10 rather than project 12. If you're considering doing this, please stop and read the book: project 12 is a technique project that adjusts project 10.

So: everything is correct; please do not email me about this.